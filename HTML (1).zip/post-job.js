import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";

import {
  getFirestore,
  collection,
  addDoc,
  serverTimestamp,
  query,
  where,
  getDocs
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

import {
  getAuth,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyD13C2N3R6b-lgr7HXipEicQKr7AinbHPA",
  authDomain: "rozgarconnect-69054.firebaseapp.com",
  projectId: "rozgarconnect-69054",
  storageBucket: "rozgarconnect-69054.firebasestorage.app",
  messagingSenderId: "260861416467",
  appId: "1:260861416467:web:0e5ba645c9301a53b79be6",
  measurementId: "G-P9HZ0BM40W"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

let currentUser = null;
let ownerName = "";
let ownerMobile = "";

/* Auth Check */
onAuthStateChanged(auth, async (user) => {

  if (!user) {
    window.location.href = "login.html";
    return;
  }

  currentUser = user;

  try {

    const q = query(
      collection(db, "users"),
      where("uid", "==", user.uid)
    );

    const snap = await getDocs(q);

    snap.forEach((docSnap) => {
      const data = docSnap.data();

      ownerName = data.name || "Customer";
      ownerMobile = data.mobile || "";
    });

  } catch (error) {
    console.error(error);
  }

});

/* Post Job */
document.getElementById("postJobBtn")
.addEventListener("click", async () => {

  try {

    const title =
      document.getElementById("jobTitle").value.trim();

    const selectedCategory =
      document.getElementById("jobCategory").value;

    const customCategory =
      document.getElementById("customCategory").value.trim();

    const city =
      document.getElementById("city").value.trim();

    const budget =
      document.getElementById("budget").value.trim();
const mobile =
document.getElementById("mobile").value.trim();
    const description =
      document.getElementById("description").value.trim();

    let finalCategory = selectedCategory;

    if (selectedCategory === "Other") {

      if (!customCategory) {
        alert("Please enter your custom category");
        return;
      }

      finalCategory = customCategory;
    }

    if (
      !title ||
      !finalCategory ||
      !city ||
      !budget ||
      !mobile ||
      !description
    ) {
      alert("Please fill all fields");
      return;
    }

    await addDoc(
      collection(db, "jobs"),
      {
        uid: currentUser.uid,

        ownerName: ownerName,
        mobile: ownerMobile,

        title: title,
        category: finalCategory,
        city: city,
        budget: budget,
        mobile: mobile,
        description: description,

        status: "Open",

        createdAt: serverTimestamp()
      }
    );

    alert("Job Posted Successfully ✅");

    window.location.href = "jobs.html";

  } catch (error) {

    console.error(error);
    alert(error.message);

  }

});