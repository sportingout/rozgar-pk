import { initializeApp }
from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";

import {
getFirestore,
doc,
getDoc,
updateDoc
}
from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

import {
getAuth,
onAuthStateChanged
}
from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

const firebaseConfig = {
apiKey: "AIzaSyD13C2N3R6b-lgr7HXipEicQKr7AinbHPA",
authDomain: "rozgarconnect-69054.firebaseapp.com",
projectId: "rozgarconnect-69054",
storageBucket: "rozgarconnect-69054.firebasestorage.app",
messagingSenderId: "260861416467",
appId: "1:260861416467:web:0e5ba645c9301a53b79be6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const params =
new URLSearchParams(window.location.search);

const jobId =
params.get("id");

if(!jobId){

alert("Job ID Missing");
window.location.href = "my-jobs.html";

}

onAuthStateChanged(auth, async(user)=>{

if(!user){

window.location.href = "login.html";
return;

}

loadJob();

});

async function loadJob(){

try{

const jobRef =
doc(db,"jobs",jobId);

const jobSnap =
await getDoc(jobRef);

if(!jobSnap.exists()){

alert("Job Not Found");
window.location.href = "my-jobs.html";
return;

}

const job =
jobSnap.data();

document.getElementById("jobTitle").value =
job.title || "";

document.getElementById("category").value =
job.category || "";

document.getElementById("city").value =
job.city || "";

document.getElementById("budget").value =
job.budget || "";

document.getElementById("description").value =
job.description || "";

document.getElementById("status").value =
job.status || "Open";

}catch(error){

console.error(error);
alert(error.message);

}

}

document
.getElementById("updateBtn")
.addEventListener("click", async()=>{

try{

const title =
document.getElementById("jobTitle").value.trim();

const category =
document.getElementById("category").value.trim();

const city =
document.getElementById("city").value.trim();

const budget =
document.getElementById("budget").value.trim();

const description =
document.getElementById("description").value.trim();

const status =
document.getElementById("status").value;

if(
!title ||
!category ||
!city ||
!budget ||
!description
){

alert("Please Fill All Fields");
return;

}

await updateDoc(
doc(db,"jobs",jobId),
{
title,
category,
city,
budget,
description,
status
}
);

alert("Job Updated Successfully ✅");

window.location.href =
"my-jobs.html";

}catch(error){

console.error(error);
alert(error.message);

}

});