import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";

import {
getFirestore,
collection,
query,
where,
getDocs,
doc,
updateDoc
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

import {
getAuth,
onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyD13C2N3R6b-lgr7HXipEicQKr7AinbHPA",
  authDomain: "rozgarconnect-69054.firebaseapp.com",
  projectId: "rozgarconnect-69054",
  storageBucket: "rozgarconnect-69054.firebasestorage.app",
  messagingSenderId: "260861416467",
  appId: "1:260861416467:web:0e5ba645c9301a53b79be6",
  measurementId: "G-P9HZ0BM40W"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const container =
document.getElementById("applicationsContainer");

onAuthStateChanged(auth, async(user)=>{

if(!user){
window.location.href="login.html";
return;
}

loadApplications(user.uid);

});

async function loadApplications(ownerUid){

try{

container.innerHTML = "Loading...";

const appQuery = query(
collection(db,"applications"),
where("ownerUid","==",ownerUid)
);

const appSnap = await getDocs(appQuery);

container.innerHTML = "";

if(appSnap.empty){

container.innerHTML = `
<div class="card">
No Applications Found
</div>
`;

return;
}

for(const appDoc of appSnap.docs){

const appData = appDoc.data();

let workerName = "Unknown";
let workerMobile = "";
let workerSkill = "";

const workerQuery = query(
collection(db,"users"),
where("uid","==",appData.workerUid)
);

const workerSnap =
await getDocs(workerQuery);

workerSnap.forEach(doc=>{

workerName =
doc.data().name || "Worker";

workerMobile =
doc.data().mobile || "";

workerSkill =
doc.data().skill || "";

});

container.innerHTML += `

<div class="card">

<h3>${workerName}</h3>

<p>
<b>📞 Mobile:</b>
${workerMobile}
</p>

<p>
<b>🛠 Skill:</b>
${workerSkill}
</p>

<p>
<b>Status:</b>
${appData.status}
</p>

<div style="
display:flex;
gap:8px;
flex-wrap:wrap;
margin-top:10px;
">

<a
href="tel:${workerMobile}"
class="btn accept"
style="text-decoration:none;"
>
📞 Call
</a>

<a
href="https://wa.me/${workerMobile}"
target="_blank"
class="btn accept"
style="text-decoration:none;"
>
🟢 WhatsApp
</a>

<button
class="btn accept"
onclick="updateStatus('${appDoc.id}','Accepted')"
>
✅ Accept
</button>

<button
class="btn reject"
onclick="updateStatus('${appDoc.id}','Rejected')"
>
❌ Reject
</button>

</div>

</div>

`;

}

}catch(error){

console.error(error);

container.innerHTML = `
<div class="card">
Error Loading Applications
</div>
`;

}

}

window.updateStatus =
async function(appId,status){

try{

await updateDoc(
doc(db,"applications",appId),
{
status: status
}
);

alert(
"Application " +
status +
" Successfully"
);

location.reload();

}catch(error){

console.error(error);
alert(error.message);

}

};