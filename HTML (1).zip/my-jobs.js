import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";

import {
getFirestore,
collection,
query,
where,
getDocs,
doc,
updateDoc,
deleteDoc
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-firestore.js";

import {
getAuth,
onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

const firebaseConfig = {
// YOUR CONFIG
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const jobsContainer =
document.getElementById("jobsContainer");

onAuthStateChanged(auth,(user)=>{

if(!user){
window.location.href="login.html";
return;
}

loadJobs(user.uid);

});

async function loadJobs(uid){

const q = query(
collection(db,"jobs"),
where("uid","==",uid)
);

const snap = await getDocs(q);

jobsContainer.innerHTML="";

if(snap.empty){

jobsContainer.innerHTML=`
<div class="card">
No Jobs Posted Yet
</div>
`;

return;
}

snap.forEach(docSnap=>{

const job = docSnap.data();

jobsContainer.innerHTML += `

<div class="card">

<h3>${job.title}</h3>

<p>📂 ${job.category}</p>

<p>📍 ${job.city}</p>

<p>💰 Rs ${job.budget}</p>

<p>🟢 ${job.status}</p>

<div class="btns">

<button
class="btn close"
onclick="toggleStatus('${docSnap.id}','${job.status}')"
>
${job.status==="Open"?"Close":"Open"}
</button>

<button
class="btn delete"
onclick="deleteJob('${docSnap.id}')"
>
Delete
</button>

</div>

</div>

`;

});

}

window.toggleStatus =
async function(jobId,current){

const newStatus =
current==="Open"
? "Closed"
: "Open";

await updateDoc(
doc(db,"jobs",jobId),
{
status:newStatus
}
);

location.reload();

}

window.deleteJob =
async function(jobId){

if(!confirm("Delete this job?"))
return;

await deleteDoc(
doc(db,"jobs",jobId)
);

location.reload();

}